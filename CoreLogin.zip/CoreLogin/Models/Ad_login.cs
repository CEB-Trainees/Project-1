﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreLogin.Models
{
    public class Ad_login
    {
        public string Admin_id { get; set; }
        public string Ad_Password { get; set; }
    }
    

}
